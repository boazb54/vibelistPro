
import React from 'react';

// This component has been disabled and cleared to comply with Spotify Developer Terms Section IV.
// It previously visualized raw audio features (Danceability, Valence, etc.) which are no longer
// fetched or stored by this application.

const AdminDataInspector: React.FC<any> = () => {
  return null;
};

export default AdminDataInspector;
