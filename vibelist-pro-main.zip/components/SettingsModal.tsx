import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';
import { SpotifyUserProfile } from '../types';
import { isRtl } from '../utils/textUtils';
import { fetchUserProfile } from '../services/historyService';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: SpotifyUserProfile | null;
  onSignOut: () => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, userProfile, onSignOut }) => {
  const [dbProfile, setDbProfile] = useState<any>(null);

  useEffect(() => {
    if (isOpen && userProfile?.id) {
       fetchUserProfile(userProfile.id).then(({ data }) => {
         if (data) setDbProfile(data);
       });
    }
  }, [isOpen, userProfile]);

  if (!isOpen) return null;

  // Render via Portal to ensure layout stability (Zero-Regression)
  return ReactDOM.createPortal(
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in">
      {/* Container with gradient border logic */}
      <div className="relative p-[1px] rounded-3xl bg-gradient-to-br from-purple-500 to-blue-500 shadow-2xl w-full max-w-md mx-4">
        <div className="bg-[#0f172a] rounded-[23px] p-6 md:p-8 relative overflow-hidden">
           {/* Close Button */}
           <button 
             onClick={onClose}
             className="absolute top-4 right-4 text-slate-400 hover:text-white transition-colors"
           >
             <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
               <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
             </svg>
           </button>

           <h2 className="text-2xl font-bold text-white mb-6">Account Settings</h2>

           {userProfile && (
             <div className="space-y-6">
               <div className="flex items-center gap-4">
                 {userProfile.images?.[0] ? (
                   <img src={userProfile.images[0].url} alt="Profile" className="w-20 h-20 rounded-full border-2 border-purple-500/30" />
                 ) : (
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center text-2xl font-bold">
                      {userProfile.display_name?.[0]}
                    </div>
                 )}
                 <div className="flex-1 min-w-0">
                    {/* RTL Logic Application */}
                    <div 
                      className={`text-xl font-bold text-white truncate ${isRtl(userProfile.display_name) ? 'text-right font-["Heebo"]' : 'text-left'}`}
                      dir={isRtl(userProfile.display_name) ? 'rtl' : 'ltr'}
                    >
                      {userProfile.display_name}
                    </div>
                    <div className="text-sm text-slate-400 truncate">{userProfile.email}</div>
                 </div>
               </div>

               <div className="bg-white/5 rounded-xl p-4 space-y-3 border border-white/5">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-400">Country</span>
                    <span className="text-white font-medium">{userProfile.country}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-400">Plan</span>
                    <span className="text-white font-medium capitalize">{userProfile.product}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-400">Member Since</span>
                    <span className="text-white font-medium">
                      {dbProfile?.created_at ? new Date(dbProfile.created_at).toLocaleDateString() : '...'}
                    </span>
                  </div>
               </div>

               <button
                 onClick={onSignOut}
                 className="w-full py-3 rounded-xl font-bold text-white bg-gradient-to-r from-orange-500 to-rose-500 hover:from-orange-400 hover:to-rose-400 shadow-lg shadow-orange-500/20 transition-all transform active:scale-95"
               >
                 Sign Out
               </button>
             </div>
           )}
        </div>
      </div>
    </div>,
    document.body
  );
};

export default SettingsModal;